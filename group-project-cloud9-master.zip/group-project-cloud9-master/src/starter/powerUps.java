
	package starter;

	public class powerUps {
		public boolean immortal = false;
		public boolean fireBalls = false;
		
		public void mortOn()
		{
			immortal = true;
		}
		
		public void mortOff()
		{
			immortal = false;
		}
		
		public void fireOn()
		{
			fireBalls = true;
		}
		
		public void fireOff()
		{
			fireBalls = false;
			
		}
	}

