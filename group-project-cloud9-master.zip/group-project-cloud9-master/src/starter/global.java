package starter;

public class global {
	public static double Vert_MAX_Velocity = 15, Horiz_MAX_Velocity = 5, walkSpeed = 1, Friction = 1,jumpSpeed = 15, Gravity = 1;
	public static int XAXIS = 100, YAXIS = 600, WIDTH = 50, HEIGHT = 50, THICKNESS = 3;
	public static int vertVelocity = 0;
	public static int horizVelocity = 0;
	public static int TimerCount = 0;
	public int onground = 0;
	
}
